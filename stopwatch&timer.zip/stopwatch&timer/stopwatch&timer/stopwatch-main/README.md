# Stop Watch using HTML,CSS and JavaScript
 
# Note : Create an issue first then make pull request :) 

### How to contribute 😎<br>

* Star this repository.
* Create an issue with description that how you want to contribute in this project.
* Then fork this repository.
* In forked repository add your changes.
* Then make pull request with issue number .
* Pull request should have screenshot of the changes you have made.
* Wait for review.


Web link -https://avinash201199.github.io/stopwatch/
<br>
If you want this project then go ahead. Fork and clone it, make changes according to you.After that you can host it on Github using github pages.For any help reach me on social media link is in profile readme. https://www.instagram.com/lets__code/
<br><br>

